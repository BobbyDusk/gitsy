# Gitsy

**A Chrome browser extension that enhances Github links with useful information.**

## Functionality

- Adds number of stars to github links.
- Adds extra information when hovering over a github link, including:
  - A Description of the Repo
  - Number of Stars ⭐
  - Number of Forks 🍴
  - Number of Open Issues 🐛
  - Number of Open PRs 🔃
  - Time since last push ⏱

![Video of hover functionality](/promo_mages/before_and_after_24fps.gif)

## Installation

1. Install the extension from the [Chrome Web Store](https://chromewebstore.google.com/detail/gitsy/anonikabdplepoefnmeiloffpaeffmmn)
2. Generate a github Token
   1. Make sure you're logged into your github account.
   2. Go to your [personal access tokens](https://github.com/settings/personal-access-tokens) (**your github account -> Settings -> Developer Settings -> Personal Access Token -> Fine-grained tokens**)
   3. Generate a new token with **Expiration: No Expiration** and **Repository Access: Public Repositories** (default).
   4. Copy and paste your github token into Gitsy extension pop-up.

## License

This project is distrubuted under GNU GPLv3. See the COPYING file for more info.
